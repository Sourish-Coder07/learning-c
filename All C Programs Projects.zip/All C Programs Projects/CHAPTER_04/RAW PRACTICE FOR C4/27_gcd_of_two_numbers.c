// // // // // // // // #include <stdio.h>
// // // // // // // // int main() {

// // // // // // // //   int num, temp, rev = 0, remainder;

// // // // // // // //   printf("Enter the number: ");
// // // // // // // //   scanf("%d", &num);

// // // // // // // //   temp = num;

// // // // // // // //   while (num != 0) {
// // // // // // // //     remainder = num % 10;
// // // // // // // //     rev = rev * 10 + remainder;
// // // // // // // //     num = num / 10;
// // // // // // // //   }

// // // // // // // //   printf("Reversed Number: %d\n", rev);

// // // // // // // //   if (temp == rev) {
// // // // // // // //     printf("The number is Palindrome!");

// // // // // // // //   } else {
// // // // // // // //     printf("The number is not Palindrome!");
// // // // // // // //   }
// // // // // // // //   return 0;
// // // // // // // // }

// // // // // // // #include <stdio.h>
// // // // // // // int main() {

// // // // // // //   int num, temp, rev = 0, remainder;

// // // // // // //   printf("Enter the number:");
// // // // // // //   scanf("%d", &num);

// // // // // // //   temp = num;

// // // // // // //   while (num != 0) {

// // // // // // //     remainder = num % 10;
// // // // // // //     rev = rev * 10 + remainder;
// // // // // // //     num = num / 10;
// // // // // // //   }

// // // // // // //   printf("Reversed number: %d\n", rev);

// // // // // // //   if (temp == rev) {
// // // // // // //     printf("This is the  palindrome!");
// // // // // // //   } else {
// // // // // // //     printf("This is not the palindrome!");
// // // // // // //   }
// // // // // // //   return 0;
// // // // // // // }

// // // // // // #include <stdio.h>
// // // // // // int main() {
// // // // // //   float p, r, t, si;

// // // // // //   printf("Enter the value of p, r, t: \n");
// // // // // //   scanf("%f %f %F", &p, &r, &t);

// // // // // //   si = (p * r * t) / 100;

// // // // // //   printf("The value of simple interest is : %.2f\n", si);
// // // // // //   return 0;
// // // // // // }

// // // // // #include <stdio.h>
// // // // // int main() {
// // // // //   int a, b, c, largest;

// // // // //   printf("Enter Three Numbers:");
// // // // //   scanf("%d %d %d", &a, &b, &c);

// // // // //   largest = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);

// // // // //   printf("The largest number among them is : %d\n", largest);
// // // // //   return 0;
// // // // // }

// // // // #include <stdio.h>
// // // // int main() {

// // // //   char op;
// // // //   float num1, num2;

// // // //   printf("Enter the operation type ('+','-','*','/')");
// // // //   scanf("%c", &op);

// // // //   printf("Enter the two numbers:");
// // // //   scanf("%f %f", &num1, &num2);

// // // //   switch (op) {

// // // //   case ('+'):
// // // //     printf("Result = %.2f", num1 + num2);
// // // //     break;

// // // //   case ('-'):
// // // //     printf("Result = %.2f", num1 - num2);
// // // //     break;

// // // //   case ('*'):
// // // //     printf("Result = %.2f", num1 * num2);
// // // //     break;

// // // //   case ('/'):
// // // //     if (num2 != 0) {
// // // //       printf("Result = %.2f", num1 / num2);
// // // //       break;
// // // //     } else {
// // // //       printf("This divition is not possible!");
// // // //       break;
// // // //     }
// // // //   default:
// // // //     printf("Invalide Operation!\n");
// // // //   }
// // // //   return 0;
// // // // }

// // // #include <stdio.h>
// // // int main() {

// // //   int num, temp, rev = 0, remainder;

// // //   printf("Enter the number:\n");
// // //   scanf("%d", &num);
// // //   temp = num;

// // //   while (num != 0) {
// // //     remainder = num % 10;
// // //     rev = rev * 10 + remainder;
// // //     num = num / 10;
// // //   }

// // //   printf("The reversed number is: %d\n", rev);

// // //   if (temp == rev) {
// // //     printf("This number is palindrome!");
// // //   } else {
// // //     printf("This number is not palindrome!");
// // //   }

// // //   return 0;
// // // }

// // #include <stdio.h>
// // int main() {
// //   int num, temp, rev = 0, remainder;

// //   printf("Enter a number:");
// //   scanf("%d", &num);

// //   temp = num;

// //   while (num != 0) {
// //     remainder = num % 10;
// //     rev = rev * 10 + remainder;
// //     num = num / 10;
// //   }

// //   printf("The reversed number is : %d\n", rev);

// //   if (temp == rev) {
// //     printf("This number is palindrome!");

// //   } else {
// //     printf("This number is not palindrome!");
// //   }
// //   return 0;
// // }

// #include <stdio.h>
// int main() {
//   int n, i, sum = 0;

//   printf("Enter the value of N:");
//   scanf("%d", &n);

//   for (i = 1; i <= n; i++) {
//     sum = sum + 1;
//   }

//   printf("The sum of the natural numbers: %d\n", sum);

//   return 0;
// }

#include <stdio.h>
int main() {

  int i, a, b, gcd;

  printf("Enter two numbers:\n");
  scanf("%d %d", &a, &b);

  for (i = 1; i <= ((a > b) ? a : b); i++) {
    if (a % i == 0 && b % i == 0) {
      gcd = i;
    }
  }
  printf("The valude of GCD = %d\n", gcd);
  return 0;
}