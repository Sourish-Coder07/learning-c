#include <stdio.h>
int main() {
  int i = 0;

  while (i <= 100) {
    if (i >= 1) {

      printf("The value of i is:%d\n", i);
      // i = i + 1;
    }
    i++;
  }
  return 0;
}