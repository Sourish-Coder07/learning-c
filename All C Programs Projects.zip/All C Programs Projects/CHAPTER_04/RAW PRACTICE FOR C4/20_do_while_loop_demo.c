#include <stdio.h>
int main() {
  int i = 0;

  do {
    printf("The Value of i is %d\n", i);
    i++;
  } while (i < 8);
  return 0;
}

// #include <stdio.h>
// int main() {
//   int i = 1;

//   while (i < 6) {
//     printf("The Value Of i Is: %d\n", i);

//     i++;
//   }
//   return 0;
// }

// #include <stdio.h>

// int main() {
//   int i = 0;

//   do {
//     printf("The value of i is : %d\n", i);
//     i++;
//   } while (i < 9);
//   return 0;
// }