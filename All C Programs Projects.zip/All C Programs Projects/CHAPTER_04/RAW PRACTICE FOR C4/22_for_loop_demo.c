#include <stdio.h>
int main() {
  int i, n = 10;

  for (i = 0; i < n; i++) {
    printf("The value of i is : %d\n", i);
  }
  return 0;
}