// #include <stdio.h>
// int main() {
//   int n, i;
//   printf("The value of n is : \n");
//   scanf("%d", &n);

//   for (i = 0; i <= n; i++) {
//     printf("the value of i is: %d\n", i);
//   }
//   return 0;
// }

