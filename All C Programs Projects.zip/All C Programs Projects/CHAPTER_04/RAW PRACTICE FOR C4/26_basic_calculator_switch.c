#include <stdio.h>
int main() {

  char op;
  float num1, num2;

  printf("Enter the oparation you want ('+','-','*','/'): \n");
  scanf("%c", &op);

  printf("Enter the two numbers for the operation: ");
  scanf("%f %f", &num1, &num2);

  switch (op) {

  case ('+'):
    printf("Result = %.2f", num1 + num2);
    break;

  case ('-'):
    printf("Result = %.2f", num1 - num2);
    break;

  case ('*'):
    printf("Result = %.2f", num1 * num2);
    break;

  case ('/'):
    if (num2 != 0) {
      printf("Result = %.2f", num1 / num2);
      break;
    } else {
      printf("The division is not posible.\n");
      break;
    }

  default:
    printf("Invalide operation!");
  }
  return 0;
}
