#include<stdio.h>
int main(){
    int length = 6;
    int width = 9;
    printf("The area of the rectangle is: %d", length * width);
    return 0;
}
