#include <stdio.h>

int main() {
    float pi = 3.14159265358979323846264338327950288419716939937510;
    float r = 6.3325441;
    printf("The area of the circle is: %f\n", pi * r * r);

    return 0;
}