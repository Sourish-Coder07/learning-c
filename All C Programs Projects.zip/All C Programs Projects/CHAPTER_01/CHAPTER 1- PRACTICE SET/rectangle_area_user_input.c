#include <stdio.h>

int main() {
    int length;
    int width;

    printf("Enter the length:\n");
    scanf("%d", &length);

    printf("Enter the width:\n");
    scanf("%d", &width);

    printf("The area of the rectangle is: %d\n", length * width);

    return 0;
}