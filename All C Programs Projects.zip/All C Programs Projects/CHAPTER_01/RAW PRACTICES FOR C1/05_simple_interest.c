# include <stdio.h>

int main(){
    int P;
    int R;
    int T;

    printf(" ENTER THE VALUE OF P: \n");
    scanf("%d", &P);

    printf(" ENTER THE VALUE OF R: \n");
    scanf("%d", &R);

    printf(" ENTER THE VALUE OF T: \n");
    scanf("%d", &T);

    printf(" THE VALUE OF SIMPLE INTEREST IS : %d\n", (P * R * T)/100);

    return 0;
}