#include <stdio.h>

int main(){

    float Pi = 3.14;
    float r;

    printf("Enter the value of R: \n");
    scanf("%f", &r);

    printf("The area of the circle is: %f\n", Pi * r * r);

    return 0;
}