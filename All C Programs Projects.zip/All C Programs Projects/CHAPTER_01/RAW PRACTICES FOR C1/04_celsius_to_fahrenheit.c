# include <stdio.h>
int main(){
    float c;
    float x = 1.8;
    float y = 32.00;

    printf(" ENTER THE VALUE OF CELSIUS: \n");
    scanf("%f", &c);

    printf("THE VALUE OF FAHRENHEIT IS: %.2f\n", (c * x) + y);

    return 0;

} 