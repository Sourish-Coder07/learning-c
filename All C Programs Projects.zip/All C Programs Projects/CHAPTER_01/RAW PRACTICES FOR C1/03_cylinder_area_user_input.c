#include <stdio.h>

int main() {

    float Pi = 3.14;
    float r;
    float n = 2.00;

    printf("ENTER THE VALUE OF THE R: ");
    scanf("%f", &r);

    printf("THE AREA OF THE CYLINDER IS: %f\n", n * Pi * r);

    return 0;
}
