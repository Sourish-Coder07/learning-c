/*3.are three subjects and take the marks as input from the user.
Calculate income tax paid by an employee to the government as per the slabs
mentioned below:
Income Slab
 Tax
2.5 – 5.0L
 5%
5.0L - 10.0L
 20%
Above 10.0L
 30%
*/

// #include <stdio.h>

// int main() {
//   int Income, Tax = 0;

//   printf("Enter Your Income: \n");
//   scanf("%d", &Income);
//   if (Income <= 250000) {
//     Tax = 0;
//   } else if (Income >= 250000 && Income <= 500000) {
//     Tax = 0.05 * (Income - 250000);
//   }

//   else if (Income >= 500000 && Income <= 1000000) {
//     Tax = 0.05 * (500000 - 250000) + 0.20 * (Income - 500000);
//   }

//   else if (Income >= 1000000) {
//     Tax = 0.05 * (500000 - 250000) + 0.20 * (1000000 - 500000) +
//           0.30 * (Income - 1000000);
//   }
//   printf("YOUR TOTAL TAX NEED TO PAY IS: %d\n", Tax);

//   return 0;
// }

#include <stdio.h>

int main() {
  float Income, Tax = 0;

  printf("Enter Your Income: ");
  scanf("%f", &Income);

  if (Income <= 250000) {
    Tax = 0;
  } else if (Income <= 500000) {
    Tax = 0.05 * (Income - 250000);
  } else if (Income <= 1000000) {
    Tax = 0.05 * (500000 - 250000) + 0.20 * (Income - 500000);
  } else {
    Tax = 0.05 * (500000 - 250000) + 0.20 * (1000000 - 500000) +
          0.30 * (Income - 1000000);
  }

  printf("YOUR TOTAL TAX NEED TO PAY IS: %.2f\n", Tax);

  return 0;
}
