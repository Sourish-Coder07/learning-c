// // 4. Write a program to find whether a year entered by the user is a leap
// year or not.
// // Take year as an input from the user.

#include <stdio.h>

int main() {
    int year;

    printf("Enter a year: ");
    scanf("%d", &year);

    if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)) {
        printf("%d is a Leap Year.\n", year);
    } else {
        printf("%d is NOT a Leap Year.\n", year);
    }

    return 0;
}

// #include <stdio.h>

// int main() {

//   int year;

//   printf("Enter year: \n");
//   scanf("%d", &year);

//   if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0) {
//     printf("%d is the Leap year\n", year);

//   } else {

//     printf("%d is not a Leap year\n", year);
//   }

//   return 0;
// }