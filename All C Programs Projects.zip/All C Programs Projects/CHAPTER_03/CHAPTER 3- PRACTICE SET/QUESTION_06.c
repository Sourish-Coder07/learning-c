// 6. Write a program to find greatest of four numbers entered by the user.
//

// #include <stdio.h>

// int main() {
//     int a, b, c, d, greatest;

//     // Take input from user
//     printf("Enter four numbers: ");
//     scanf("%d %d %d %d", &a, &b, &c, &d);

//     // Assume the first number is greatest initially
//     greatest = a;

//     if (b > greatest) {
//         greatest = b;
//     }
//     if (c > greatest) {
//         greatest = c;
//     }
//     if (d > greatest) {
//         greatest = d;
//     }

//     printf("The greatest number is: %d\n", greatest);

//     return 0;
// }

#include <stdio.h>
int main() {
  int a, b, c, d, Greatest;

  printf("Enter Four Numbers: \n");
  scanf("%d %d %d %d", &a, &b, &c, &d);

  Greatest = a;

  if (b > Greatest) {
    Greatest = b;
  }

  if (c > Greatest) {
    Greatest = c;
  }

  if (d > Greatest) {
    Greatest = d;
  }

  printf("The Greatest Number Is: %d\n");
  return 0;
}
