/* Write a program to determine whether a student has passed or failed. To pass,
a student requires a total of 40% and at least 33% in each subject. Assume there
are three subjects and take the marks as input from the user.*/

// #include <stdio.h>

// int main() {
//   float s1, s2, s3;
//   float total;

//   printf("Enter marks of 3 subjects:\n");
//   scanf("%f %f %f", &s1, &s2, &s3);

//   total = (s1 + s2 + s3) / 3;

//   if (total >= 40 && s1 >= 33 && s2 >= 33 && s3 >= 33) {
//     printf("Student has PASSED\n");
//   } else {
//     printf("Student has FAILED\n");
//   }

//   return 0;
// }

#include <stdio.h>

int main() {
  float Bengali;
  float English;
  float Mathematics;
  float Total_Avg;

  printf("Enter The Marks Of Bengali:\n");
  scanf("%f", &Bengali);

  printf("Enter The Marks Of English:\n");
  scanf("%f", &English);

  printf("Enter The Marks Of Mathematics:\n");
  scanf("%f", &Mathematics);

  Total_Avg = (Bengali + English + Mathematics) / 3;

  // printf("Average = %.2f\n", Total_Avg);

  if (Total_Avg >= 44 && Bengali >= 33 && English >= 33 && Mathematics >= 33) {

    printf("You are passed!\n\
Congratulations on passing your exam!\n\
Your hard work and dedication have truly paid off,\n");

  } else {
    printf("Sorry! Better luck next time..");
  }

  return 0;
}
