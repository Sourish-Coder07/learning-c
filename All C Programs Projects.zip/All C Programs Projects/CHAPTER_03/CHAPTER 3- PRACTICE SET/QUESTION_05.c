// 5. Write a program to determine whether a character entered by the user is
// lowercase or not.

#include <stdio.h>

int main() {

  char Ch;

  printf("Enter The Character: \n");
  scanf("%c", &Ch);

  if (Ch >= 'a' && Ch <= 'z') {
    printf("This Character is in Lowercase\n");
  } else {
    printf("This character is in Uppercase\n");
  }
  return 0;
}
