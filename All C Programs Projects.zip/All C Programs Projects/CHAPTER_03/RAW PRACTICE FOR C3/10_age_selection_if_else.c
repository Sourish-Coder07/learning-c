#include <stdio.h>
int main() {
  int Age;

  printf("Enter your Age: \n");
  scanf("%d", &Age);

  if (Age > 18) {
    printf("You are selected, because your age is greater than 18");
  } else {
    printf("Sorry You are not selected, because your age is less than 18");
  }
  return 0;
}