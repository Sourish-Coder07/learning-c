#include <stdio.h>

int main() {

  int a;

  printf("Enter the value of a:\n");
  scanf("%d", &a);

  switch (a) {
  case 1:
    printf("You entered case number 1\n");
    break;

  case 2:
    printf("You entered case number 2\n");
    break;

  case 3:
    printf("You entered case number 3\n");
    break;

  case 4:
    printf("You entered case number 4\n");
    break;

  default:
    printf("Invalid case number\n");
  }

  return 0;
}
