#include <stdio.h>
int main() {
  int Age;

  printf("Enter your Age: \n");
  scanf("%d", &Age);

  if (Age >= 60) {
    printf("You can drive, and also you are a senior citizen\n");
  }

  else if (Age >= 40) {
    printf("You can drive, you are elder\n");
  }

  else if (Age >= 18) {
    printf("You can drive\n");
  }

  else {
    printf("sorry!, you can't drive.. you are under 18\n");
  }
  return 0;
}