#include <stdio.h>

int main() {
  int a, b;

  printf("Enter the value of a:\n");
  scanf("%d", &a);

  printf("Enter the value of b:\n");
  scanf("%d", &b);

  a > b ? printf("a is greater then b\n") : printf("b is greater then a\n");

  return 0;
}