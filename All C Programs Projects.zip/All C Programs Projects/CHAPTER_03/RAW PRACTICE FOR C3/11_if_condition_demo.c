#include <stdio.h>

int main() {
  if (12) {
    printf("The if function is runned!\n");
  }

  if (2546) {
    printf("The if function is also runned!\n");
  }

  if ('c') {
    printf("The if function is also runned!\n");
  }

  if (0) {
    printf("The if function is not runned brcause of 0\n");
  }

  return 0;
}