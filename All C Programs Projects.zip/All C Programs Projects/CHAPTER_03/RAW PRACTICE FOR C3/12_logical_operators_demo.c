#include <stdio.h>

int main() {
  int a = 1;
  int b = 1;

  printf("The value of a and b is: %d\n", a && b);
  printf("The value of a or b is: %d\n", a || b);
  printf("The value of NOT(a) is: %d\n", !a);

  if (a && b) {
    printf("Both are True.\n");
  } else {
    printf("Both are not True.\n");
  }

  return 0;
}