// // 5.3.0 + 1 will be:
// a. Integer.
// b. Floating point number.
// c. Character.

#include <stdio.h>

int main() {
  printf("3.0 + 1 will be:\nFloating point number.");
  return 0;
}