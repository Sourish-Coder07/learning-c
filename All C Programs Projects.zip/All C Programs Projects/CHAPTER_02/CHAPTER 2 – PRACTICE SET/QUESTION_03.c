// 3.Write a program to check whether a number is divisible by 97 or not.

#include <stdio.h>

int main() {
  int a;
  int b = 97;

  printf("ENTER A NUMBER: \n");
  scanf("%d", &a);

  if (a % b == 0) {
    printf("The number %d is divisible by 97.\n", a);
  } else {
    printf("The number %d is not divisible by 97.\n", a);
  }

  return 0;
}
