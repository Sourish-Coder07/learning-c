
// 1.Which of the following is invalid in C?
// a. int a=1; int b = a;
// b. int v = 3*3;
// c. char dt = ‘21 dec 2020’;

#include <stdio.h>

int main() {
  printf("The following invalid C is: \n ");
  printf("c. char dt = ‘21 dec 2020’\n");

  return 0;
}