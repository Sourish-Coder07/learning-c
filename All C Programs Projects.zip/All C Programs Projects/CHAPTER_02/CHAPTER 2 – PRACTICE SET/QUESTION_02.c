// 2. What data type will 3.0/8 – 2 return?

#include <stdio.h>

int main() {

  float a = 3.0;
  int b = 8;
  int c = 2;

  printf("The value of the numarical is:%f", a / b - c);

  return 0;
}