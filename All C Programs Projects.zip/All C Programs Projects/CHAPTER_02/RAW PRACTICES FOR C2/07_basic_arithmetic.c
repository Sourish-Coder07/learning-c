#include <stdio.h>

int main() {
  int a = 52;
  int b = 64;
  int c = a + b;

  printf(" THE VALUE OF a IS %d AND THE VALUE OF b IS %d AND THE SUM IS %d\n",
         a, b, c);

  printf("THE REMINDER WHEN a IS DIVIDED BY b IS: %d\n", a % b);

  return 0;
}
  