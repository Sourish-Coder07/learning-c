#include <stdio.h>

int main() {
  float a = 9.0;
  int b = 6;
  float c = a / b;

  printf("The value of C is: %.2f\n", c);
  return 0;
}