#include <stdio.h>
int main() {
  int a = 5;
  int b = 7;
  int c = 5;
  int d = 3;

  printf("The value of the numarical is: %d\n",
         (a * b / c + 6 * a - 9 / 3) * d);
  // (a*b/c+6*a-9/3)*d
  // (35/c+30-3)*d
  // (7+30-3)*d
  // (34)*d
  // 102

  return 0;
}