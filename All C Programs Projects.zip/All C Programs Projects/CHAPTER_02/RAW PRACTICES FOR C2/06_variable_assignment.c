#include <stdio.h>

int main() {
  int i = 1;
  int k = i;

  printf(" THE VALUE OF i IS %d AND THE VALUE OF k IS %d", i, k);

  return 0;
}
